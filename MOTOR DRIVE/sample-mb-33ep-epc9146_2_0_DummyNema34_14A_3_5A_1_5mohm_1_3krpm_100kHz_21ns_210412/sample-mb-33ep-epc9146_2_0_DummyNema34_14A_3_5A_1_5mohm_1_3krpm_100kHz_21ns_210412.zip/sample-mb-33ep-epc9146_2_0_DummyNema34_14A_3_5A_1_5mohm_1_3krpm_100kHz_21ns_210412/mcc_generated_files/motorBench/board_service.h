/**
 * board_service.h
 * 
 * Provides hardware-independent board service components with interfaces
 * extending into the HAL.
 * 
 * Component: HAL
 */

/* *********************************************************************
 *
 * Motor Control Application Framework
 * R5/RC11 (commit 98456, build on 2020 Feb 07)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#ifndef __MCAF_BOARD_SERVICE_H
#define __MCAF_BOARD_SERVICE_H

#include <stdbool.h>
#include "hal.h"
#include "board_service_types.h"

#ifdef __cplusplus
extern "C" {
#endif
    
/**
 * Configures the board. Momentarily uses one of the device timer to clock the 
 * configuration process. This function is intended to be called from the main 
 * process during initialization phase, only after 
 * the SYSTEM_Initialize() completes. This function expects timer 2 to be 
 * configured before entry.
 * @param pBoard pointer to the board data
 */
void MCAF_BoardConfigure(MCAF_BOARD_DATA *pBoard);

/**
 * Runs the board service to take care of board faults, button and LED tasks. This
 * function is intended to be called from the main loop as frequently as possible.
 * Ideally, this function should be called at the same or faster rate as the ISR that
 * drives the MCAF_BoardServiceStepIsr() function. Internally, this function uses the
 * pBoard->isrCount variable to prescale the execution of board service routines, where
 * pBoard->isrCount is the variable that is incremented in the MCAF_BoardServiceStepIsr().
 * @param pBoard pointer to the board data
 */
void MCAF_BoardService(MCAF_BOARD_DATA *pBoard);

/**
 * Executes board service tasks that are needed to be run from the ADC ISR.
 * @param pBoard pointer to the board data
 */
void MCAF_BoardServiceStepIsr(MCAF_BOARD_DATA *pBoard);

/**
 * Initializes the state variables used by the bootstrap charging routine. This function
 * is intended to be called before the bool MCAF_BootstrapChargeExecute() after a board
 * power up event.
 * @param pBoard pointer to the board data
 */
void MCAF_BootstrapChargeInitialize(MCAF_BOARD_DATA *pBoard);

/**
 * Executes the bootstrap charging sequence. This is a non-blocking type function that
 * implements a state machine to soft-start the board by sequentially ramping up phase
 * duty cycle values to the desired value.
 * @param pBoard
 * @return bool value true when bootstrap sequence is complete
 */
bool MCAF_BootstrapChargeExecute(MCAF_BOARD_DATA *pBoard);

#ifdef __cplusplus
}
#endif

#endif /* __MCAF_BOARD_SERVICE_H */