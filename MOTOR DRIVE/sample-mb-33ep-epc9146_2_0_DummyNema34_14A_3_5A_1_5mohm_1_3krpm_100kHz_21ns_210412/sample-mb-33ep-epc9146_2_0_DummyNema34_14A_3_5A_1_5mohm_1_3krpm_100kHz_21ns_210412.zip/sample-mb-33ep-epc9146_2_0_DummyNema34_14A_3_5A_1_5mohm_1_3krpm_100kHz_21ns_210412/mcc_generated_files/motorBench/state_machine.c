/**
 * state_machine.c
 * 
 * Top-level motor controller state-machine
 * 
 * Component: state machine
 */

/* *********************************************************************
 * 
 * Motor Control Application Framework
 * R5/RC11 (commit 98456, build on 2020 Feb 07)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#include <stdint.h>
#include <stdbool.h>
#include "system_state.h"
#include "foc.h"
#include "adc_compensation.h"
#include "commutation.h"
#include "parameters/hal_params.h"
#include "parameters/operating_params.h"
#include "parameters/timing_params.h"
#include "board_service.h"
#include "hal.h"
#include "recover.h"
#include "stall_detect.h"
#include "util.h"
#include "monitor.h"
#include "error_codes.h"
#include "ui.h"

inline static void MCAF_SetPwmMinimalImpact(void)
{
    HAL_PWM_LowerTransistorsDutyCycle_Set(HAL_PARAM_PWM_PERIOD_COUNTS, 
            HAL_PARAM_MIN_LOWER_DUTY_COUNTS);
}

/**
 * Initializes PWM registers for normal operation and
 * set a default "safe" duty cycle
 */
inline static void EnablePwmMinDuty(void)
{
    HAL_PWM_DutyCycle_SetIdentical(HAL_PARAM_MIN_DUTY_COUNTS);
    HAL_PWM_UpperTransistorsOverride_Disable();
}

/**
 * Resets coastdown timer state.
 * 
 * @param pmotor motor state data
 */
inline static void MCAF_CoastdownTimerReset(MCAF_MOTOR_DATA *pmotor)
{
    pmotor->coastdown.timer = pmotor->coastdown.duration;
    pmotor->coastdown.rate  = 1;
}

/**
 * Updates coastdown timer state.
 * 
 * @param pmotor motor state data
 * @return true if timer has expired
 */
inline static bool MCAF_CoastdownTimerUpdate(MCAF_MOTOR_DATA *pmotor)
{
    int32_t newtimer = pmotor->coastdown.timer - pmotor->coastdown.rate;
    const bool stopNow = MCAF_TestHarnessCheckStopNowAndReset(&pmotor->testing);
    const bool expired = (newtimer <= 0) || stopNow;
                          
    if (expired)
    {
        newtimer = 0;
    }
    pmotor->coastdown.timer = newtimer;
    return expired;
}

/** 
 * Reset state variables for recovery:
 * if there is user intervention and runRequested is no longer true,
 * we allow retry efforts to make a fresh start.
 */
inline void MCAF_ResetRecoveryIfNotRunRequested(MCAF_MOTOR_DATA *pmotor)
{
    const bool runRequested = pmotor->ui.run;
    if (!runRequested)
    {
        MCAF_RecoveryReset(&pmotor->recovery);
    }    
}

/**
 * Executes actions on entry to the STOPPED state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnStoppedInit(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_MonitorRecoveryAcknowledged(pmotor);
    MCAF_RecoverySetInputFlag(&pmotor->recovery, MCAF_RECOVERY_FSMI_STOP_COMPLETED);
    MCAF_StallDetectReset(&pmotor->stallDetect);
    MCAF_StallDetectDeactivate(&pmotor->stallDetect);
    MCAF_FaultDetectReset(&pmotor->faultDetect);
    /* faults/failures are reset by re-init */
}

/**
 * Executes actions in the STOPPED state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnStopped(MCAF_MOTOR_DATA *pmotor)
{    
    MCAF_ResetRecoveryIfNotRunRequested(pmotor);
}

/**
 * Executes actions on entry to STARTING state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnStartingInit(MCAF_MOTOR_DATA *pmotor)
{       
    MCAF_CommutationStartupInit(pmotor);
    MCAF_FocInitializeIntegrators(pmotor);
    MCAF_StallDetectActivate(&pmotor->stallDetect);

    EnablePwmMinDuty();
}

/**
 * Executes actions common to the "active states":
 * - STARTING
 * - RUN
 * - TEST_ENABLE
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnActiveStates(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_FocStepIsrForwardPath(pmotor);
    
    {
        uint16_t pwmDutyCycle[3];
        
        pwmDutyCycle[0] = UTIL_LimitMinimumU16(pmotor->pwmDutycycle.dutycycle1, HAL_PARAM_MIN_DUTY_COUNTS);
        pwmDutyCycle[1] = UTIL_LimitMinimumU16(pmotor->pwmDutycycle.dutycycle2, HAL_PARAM_MIN_DUTY_COUNTS);
        pwmDutyCycle[2] = UTIL_LimitMinimumU16(pmotor->pwmDutycycle.dutycycle3, HAL_PARAM_MIN_DUTY_COUNTS);
        HAL_PWM_DutyCycle_Set(pwmDutyCycle);
    }
}

/**
 * Executes actions on the STARTING state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnStarting(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_MotorControllerOnActiveStates(pmotor);
}

/**
 * Executes actions on entry to the RUNNING state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnRunningInit(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_CommutationTransitionToClosedLoop(pmotor);
}

/**
 * Executes actions in the RUNNING state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnRunning(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_MotorControllerOnActiveStates(pmotor);
}

/**
 * Executes actions on entry to the STOPPING state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnStoppingInit(MCAF_MOTOR_DATA *pmotor)
{
    pmotor->omegaCmd = 0;
    MCAF_SetPwmMinimalImpact();
    MCAF_IncrementStopCount(pmotor);
    MCAF_CoastdownTimerReset(pmotor);
}

/**
 * Executes actions in the STOPPING state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnStopping(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_ResetRecoveryIfNotRunRequested(pmotor);
}

/**
 * Executes actions on entry to the FAULT state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnFaultInit(MCAF_MOTOR_DATA *pmotor)
{
    pmotor->ui.run = false;
    MCAF_SetPwmMinimalImpact();
}

/**
 * Executes actions in the FAULT state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnFault(MCAF_MOTOR_DATA *pmotor)
{
    /* do nothing */
}

/**
 * Executes actions on entry to the TEST_DISABLE state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnTestDisableInit(MCAF_MOTOR_DATA *pmotor)
{
    /* do nothing */
}

/**
 * Executes actions in the TEST_DISABLE state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnTestDisable(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_SetPwmMinimalImpact();
}

/**
 * Executes actions in the TEST_RESTART state.
 * 
 * @param pmotor motor state data
 * @param init whether this is entry to the TEST_RESTART state
 */
inline void MCAF_MotorControllerOnTestRestart(MCAF_MOTOR_DATA *pmotor, bool init)
{
    /* First time here: we need to delay for at least one cycle.
     */
    if (init)
    {
        /* 
         * Put PWMs in a safe state to keep gate drive going.
         * Clear latching PWM fault and delay for at least one ISR cycle.
         */
        MCAF_BootstrapChargeInitialize(&pmotor->board);
        HAL_PWM_FaultClearBegin();
        MCAF_FocRestart(pmotor);
        
        MCAF_FocInitializeIntegrators(pmotor);
    }
    /* Otherwise, delay some number of samples for fault-latch circuitry 
     * to stabilize, then re-enable PWM fault latching.
     * (PWM peripheral requires the interval between disable
     * and reenable to straddle the PWM boundary)
     */
    else if (!MCAF_OvercurrentHWFlagValid(pmotor))
    {
        MCAF_OvercurrentHWFlagAttemptClear(pmotor);
    }    
    else
    {
        MCAF_TestHarness_ClearRestartRequired(&pmotor->testing);
    }
}

/**
 * Executes actions on entry to the TEST_ENABLE state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnTestEnableInit(MCAF_MOTOR_DATA *pmotor, MCAF_FSM_STATE previous_state)
{
    /* Special-case entering the enable state from the following circumstance:
     * - STARTUP_PAUSE override flag set
     * - left STARTING state 
     */
    if (   MCAF_OverrideStartupPause(&pmotor->testing)
        && previous_state == MCSM_STARTING)
    {
        ; 
        /*
         * do nothing: we don't want to mess with the PWM duty cycles
         * in a mode where switching is already occurring
         */
    }
    else
    {
        EnablePwmMinDuty();
    }
}

/**
 * Executes actions in the TEST_ENABLE state.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnTestEnable(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_MotorControllerOnActiveStates(pmotor);
}

inline void MCAF_MotorControllerOnRestartInit(MCAF_MOTOR_DATA *pmotor)
{
    /* 
     * Put PWMs in a safe state to keep gate drive going.
     * Clear latching PWM fault and delay for at least one ISR cycle.
     */
    MCAF_BootstrapChargeInitialize(&pmotor->board);
    HAL_PWM_FaultClearBegin();
    
    MCAF_FocRestart(pmotor);
    
    MCAF_UiRestart(&pmotor->ui);
    MCAF_TestHarness_Restart(&pmotor->testing);
    MCAF_CommutationRestart(pmotor);
    MCAF_StallDetectReset(&pmotor->stallDetect);
    MCAF_StallDetectDeactivate(&pmotor->stallDetect);
    MCAF_FaultDetectInit(&pmotor->faultDetect);
    MCAF_RecoveryInit(&pmotor->recovery);
}

/**
 * Executes actions in the RESTART state.
 * 
 * @param pmotor motor state data
 * @param init true if this is the first time we enter this state
 */
inline void MCAF_MotorControllerOnRestart(MCAF_MOTOR_DATA *pmotor, bool init)
{
    /* First time here: we need to delay for at least one cycle.
     */
    if (init)
    {
        /* do nothing */
    }
    /* Otherwise, delay some number of samples for fault-latch circuitry 
     * to stabilize, then re-enable PWM fault latching.
     * (PWM peripheral requires the interval between disable
     * and reenable to straddle the PWM boundary)
     */
    else if (!MCAF_OvercurrentHWFlagValid(pmotor))
    {
        MCAF_OvercurrentHWFlagAttemptClear(pmotor);
    }
    else
    {
        MCAF_ADCCalibrateCurrentOffsets(&pmotor->initialization,
                                        &pmotor->currentCalibration,
                                        &pmotor->iabc);
    }
}

/**
 * Executes actions common to all states.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnAllStates(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_ADCRead(pmotor);
    MCAF_FocStepIsrFeedbackPath(pmotor);
    MCAF_CommutationPrepareStallDetectInputs(pmotor);
    MCAF_MonitorSysDiagnose(pmotor);
}

/**
 * Executes low-priority actions common to all states.
 * 
 * @param pmotor motor state data
 */
inline void MCAF_MotorControllerOnAllStatesLowPriority(MCAF_MOTOR_DATA *pmotor)
{   
    MCAF_FocStepIsrNonCriticalTask(pmotor);
    MCAF_TestGuard(&pmotor->testing, &pmotor->psys->testing);
    MCAF_TestPerturbationUpdate(&pmotor->testing);
}

/**
 * Determines transition in state machine in the primary modes 
 * (those modes aside from test modes)
 *
 * Side effect: report any new error to the UI.
 * 
 * @param pmotor motor data
 * @return next state
 */
inline MCAF_FSM_STATE MCAF_FSM_DetermineNextState(MCAF_MOTOR_DATA *pmotor)
{
    /* By default, we stay in the same state. */
    const MCAF_FSM_STATE this_state = pmotor->state;
    MCAF_FSM_STATE next_state = this_state;    
    
    /* Check if a fault has been detected. 
     * Mask reporting of new faults during the FAULT state; this is okay,
     * because if they are still around when we re-enter the RESTART state,
     * we'll drop back into the FAULT state.
     */
    const bool operating_fault_detected = 
        (next_state != MCSM_FAULT) &&
        MCAF_DetectFault(pmotor, FDM_PRIMARY);

    if (operating_fault_detected)
    {
        next_state = MCSM_FAULT;
        const uint16_t error_code = MCAF_GetFaultCode(pmotor);
        MCAF_UiRecordNewError(&pmotor->ui.indicatorState, error_code);
    }
    else
    {
        const bool run_requested = 
            pmotor->ui.run && 
            !MCAF_UiHasDirectionChanged(&pmotor->ui);
        const bool run_permitted =
            MCAF_MonitorIsRunPermitted(pmotor)
         || MCAF_OverrideStallDetection(&pmotor->testing);
        const bool run = run_requested && run_permitted;
        switch (this_state)
        {
            case MCSM_RESTART:
                {
                    const bool adcReady = MCAF_ADCInitializationReady(pmotor);
                    const bool boardReady = MCAF_BootstrapChargeExecute(&pmotor->board);
                    if (adcReady && boardReady)
                    {
                        next_state = MCSM_STOPPING;
                    }
                }
                break;
            case MCSM_STOPPED:
                if (run) 
                {
                    next_state = MCSM_STARTING;
                }
                break;
            case MCSM_STARTING:
                if (!run)
                {
                    next_state = MCSM_STOPPING;
                }
                else if (pmotor->startup.complete)
                {
                    next_state = MCSM_RUNNING;
                }
                break;
            case MCSM_RUNNING:
                if (!run)
                {
                    next_state = MCSM_STOPPING;
                }
                break;
            case MCSM_STOPPING:
                {
                    const bool timerExpired = MCAF_CoastdownTimerUpdate(pmotor);
                    const bool stop_complete = 
                        MCAF_MonitorIsMotorStopped(pmotor)
                        && timerExpired;
                    if (stop_complete)
                    {
                        next_state = MCSM_STOPPED;
                    }                    
                }
                break;
            case MCSM_FAULT:
                {
                    const bool ok_to_restart = pmotor->ui.run;
                    if (ok_to_restart)
                    {
                        next_state = MCSM_RESTART;
                    }
                }
                break;
            default:
                next_state = MCSM_RESTART;
        }
    }    
    return next_state;
}

/**
 * Determines transition in state machine in the test modes
 * 
 * Side effect: report any new error to the UI.
 * 
 * @param pmotor motor data
 * @return next state
 */
inline MCAF_FSM_STATE MCAF_FSM_DetermineNextStateTestMode(MCAF_MOTOR_DATA *pmotor)
{    
    MCAF_FSM_STATE next_state;    
    uint16_t error_code = ERR_NO_ERROR;
    const bool test_fault_detected = MCAF_DetectFault(pmotor, FDM_TEST);

    if (test_fault_detected)
    {
        MCAF_UiRecordNewError(&pmotor->ui.indicatorState, error_code);
    }

    if (MCAF_GetOperatingMode(&pmotor->testing) == OM_DISABLED)
    {
        next_state = MCSM_TEST_DISABLE;
    }
    else  // operating mode != disabled
    {
        if (MCAF_TestHarness_TestRestartRequired(&pmotor->testing))
        {
            next_state = MCSM_TEST_RESTART;
        }
        else if (test_fault_detected)
        {
            next_state = MCSM_TEST_DISABLE;
        }
        else
        {
            next_state = MCSM_TEST_ENABLE;
        }
    }
    return next_state;
}

/**
 * Performs actions appropriate in each state, including on-entry actions
 * 
 * @param pmotor motor data
 * @param next_state the next state of the state machine
 */
inline void MCAF_FSM_Dispatch(MCAF_MOTOR_DATA *pmotor, MCAF_FSM_STATE next_state)
{
    const MCAF_FSM_STATE this_state = pmotor->state;
    const bool state_changed = (next_state != this_state);
    pmotor->state = next_state;
    
    switch (next_state)
    {
        case MCSM_RESTART:
            if (state_changed)
            {
                MCAF_MotorControllerOnRestartInit(pmotor);
            }
            MCAF_MotorControllerOnRestart(pmotor, state_changed);
            break;
        case MCSM_STOPPED:
            if (state_changed)
            {
                MCAF_MotorControllerOnStoppedInit(pmotor);
            }
            MCAF_MotorControllerOnStopped(pmotor);
            break;
        case MCSM_STARTING:
            if (state_changed)
            {
               MCAF_MotorControllerOnStartingInit(pmotor);
            }
            MCAF_MotorControllerOnStarting(pmotor);
            break;
        case MCSM_RUNNING:
            if (state_changed)
            {
                MCAF_MotorControllerOnRunningInit(pmotor);
            }
            MCAF_MotorControllerOnRunning(pmotor);
            break;
        case MCSM_STOPPING:
            if (state_changed)
            {
                MCAF_MotorControllerOnStoppingInit(pmotor);
            }
            MCAF_MotorControllerOnStopping(pmotor);
            break;                    
        case MCSM_FAULT:
            if (state_changed)
            {
                MCAF_MotorControllerOnFaultInit(pmotor);
            }
            MCAF_MotorControllerOnFault(pmotor);
            break;                    
        case MCSM_TEST_DISABLE:
            if (state_changed)
            {
                MCAF_MotorControllerOnTestDisableInit(pmotor);
            }
            MCAF_MotorControllerOnTestDisable(pmotor);
            break;                    
        case MCSM_TEST_RESTART:
            MCAF_MotorControllerOnTestRestart(pmotor, state_changed);
            break;
        case MCSM_TEST_ENABLE:
            if (state_changed)
            {
                MCAF_MotorControllerOnTestEnableInit(pmotor, this_state);
            }
            MCAF_MotorControllerOnTestEnable(pmotor);
            break;
    }    
}


/* ----- implementations of functions used outside this module: ----- */

void MCAF_SystemStateMachine_StepIsr(MCAF_MOTOR_DATA *pmotor)
{
    MCAF_CaptureTimestamp(&pmotor->testing, MCTIMESTAMP_STATEMACH_START);

    /* 1. Perform critical tasks that are independent of the state. */
    MCAF_MotorControllerOnAllStates(pmotor);
    
    MCAF_CaptureTimestamp(&pmotor->testing, MCTIMESTAMP_STATEMACH_ON_ALL_STATES);

    /* 2. Determine next state. */
    const MCAF_FSM_STATE next_state =
    #ifdef MCAF_TEST_HARNESS
        pmotor->testing.operatingMode == OM_NORMAL 
            ? MCAF_FSM_DetermineNextState(pmotor)
            : MCAF_FSM_DetermineNextStateTestMode(pmotor);
    #else
        MCAF_FSM_DetermineNextState(pmotor);
    #endif

    MCAF_CaptureTimestamp(&pmotor->testing, MCTIMESTAMP_STATEMACH_NEXT_STATE);
    
    /* 3. Update state and execute appropriate actions. */
    MCAF_FSM_Dispatch(pmotor, next_state);

    MCAF_CaptureTimestamp(&pmotor->testing, MCTIMESTAMP_STATEMACH_DISPATCH);

    /* 4. Perform noncritical tasks that are independent of the state. */
    MCAF_MotorControllerOnAllStatesLowPriority(pmotor);

    MCAF_CaptureTimestamp(&pmotor->testing, MCTIMESTAMP_STATEMACH_END);
}

void MCAF_SystemStateMachine_Init(MCAF_MOTOR_DATA *pmotor)
{
    pmotor->state = MCSM_RESTART;
    pmotor->coastdown.duration = VELOCITY_COASTDOWN_TIME;
    MCAF_TestHarness_Init(&pmotor->testing);
    MCAF_MotorControllerOnRestartInit(pmotor);    
    MCAF_CommutationInit(pmotor);
    pmotor->initialization.faultLatchDelay = MCAF_POWERUP_FAULT_LATCH_DELAY;
    
    /* Start Timer-1, used for implementing time profiling
     * feature within the test harness */
    HAL_ProfilingCounter_Start();
}

void MCAF_SystemStateMachine_StepMain(volatile MCAF_MOTOR_DATA *pmotor)
{
    /* Fault display is stateful: we only set it up once,
     * and afterwards we leave things alone. 
     *
     * Regular status display is stateless: it's just a slow PWM
     * for the LEDs
     */
    if (pmotor->state != MCSM_FAULT)
    {
        uint8_t duty1;
        uint8_t duty2;
        /* Mapping between system state and duty cycle of LED blink */
        switch (pmotor->state)
        {
            case MCSM_RESTART:
            default:
                duty1 = MCUILD_OFF;
                duty2 = MCUILD_OFF;
                break;
            case MCSM_STOPPED:
                duty1 = MCUILD_LOW;
                duty2 = MCUILD_OFF;
                break;
            case MCSM_STARTING:
                duty1 = MCUILD_LOW;
                duty2 = MCUILD_ON;
                break;
            case MCSM_STOPPING:
                duty1 = MCUILD_HIGH;
                duty2 = MCUILD_OFF;
                break;
            case MCSM_RUNNING:
                duty1 = MCUILD_HIGH;
                duty2 = MCUILD_ON;
                break;
        }

        if (pmotor->ui.flags & MCAF_UI_REVERSE)
        {
            pmotor->ui.indicatorState.duty1 = duty1;        
            pmotor->ui.indicatorState.duty2 = duty2;        
        }
        else
        {
            pmotor->ui.indicatorState.duty1 = duty2;        
            pmotor->ui.indicatorState.duty2 = duty1;        
        }
    }
    MCAF_TestHarnessHandleForceStateChange(&pmotor->testing, &pmotor->ui.run);
}
