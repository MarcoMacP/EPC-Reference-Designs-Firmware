/**
 * foc.c
 * 
 * main field-oriented-control code
 * 
 * Component: FOC
 */

/* *********************************************************************
 *
 * Motor Control Application Framework
 * R5/RC11 (commit 98456, build on 2020 Feb 07)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#include <stdint.h>
#include "util.h"
#include "adc_compensation.h"
#include "parameters/sat_PI_params.h"
#include "parameters/foc_params.h"
#include "parameters/hal_params.h"
#include "parameters/timing_params.h"
#include "motor_control.h"
#include "motor_control_function_mapping.h"
#include "system_state.h"
#include "foc.h"
#include "commutation.h"
#include "startup.h"
#include "math_asm.h"
#include "sat_PI.h"
#include "hal.h"

/* ------------------------- Initialization ------------------------- */

int16_t MCAF_ComputeReciprocalDCLinkVoltage(int16_t vdc);

/** 
 * Initializes required parameters 
 * 
 * @param pmotor motor data
 */
inline static void initStateParameters(MCAF_MOTOR_DATA *pmotor)
{

    /* ============= Open Loop Startup ====================== */
    MCAF_StartupTransitioningInit(&pmotor->startup);

    MCAF_ADCCompensationInit(&pmotor->initialization,
                             &pmotor->currentCalibration); 
    pmotor->rVdc = MCAF_ComputeReciprocalDCLinkVoltage(INT16_MAX);
}

/**
 * Initialize controller state
 * 
 * @param pmotor motor data
 */
inline static void initControlLoopState(MCAF_MOTOR_DATA *pmotor)
{
    pmotor->idCtrl.integrator = 0;
    pmotor->iqCtrl.integrator = 0;
    pmotor->omegaCtrl.integrator = 0;
    pmotor->vdqCmd.d = 0;
    pmotor->vdqCmd.q = 0;
    pmotor->idqCmdRaw.d = 0;
    pmotor->idqCmdRaw.q = 0;
}

bool MCAF_FocInit(MCAF_MOTOR_DATA *pmotor, MCAF_SYSTEM_DATA *psys)
{
    pmotor->psys = psys;

    initControlLoopState(pmotor);

    pmotor->controlFlags = 0;    
    
    /* initialize the mux'd channel (doesn't matter which setting is first) */
    pmotor->adcSelect = HADC_POTENTIOMETER;
    
    initStateParameters(pmotor);
    
    MCAF_SatInit(&pmotor->sat);
    return true;
}

/* ------------------------- Runtime ------------------------- */

/*
 * 1. Feedback path
 */

void MCAF_FocStepIsrFeedbackPath(MCAF_MOTOR_DATA *pmotor)
{
    /* Clarke transform */
    MC_TransformClarke(&pmotor->iabc, &pmotor->ialphabeta);

    /* Park transform */
    MC_TransformPark(&pmotor->ialphabeta, &pmotor->sincos, &pmotor->idq);

    /* Calculate commutation angle using estimator */
    MCAF_CommutationStep(pmotor);

    /* Calculate Sine and Cosine from pmotor->theta_e */
    MC_CalculateSineCosine(pmotor->thetaElectrical, &pmotor->sincos);
}

/*
 * 2. Controllers for current/velocity/etc.
 */

/**
 * Limits the slew rate of current commands.
 * (For now, does nothing.)
 * 
 * @param pidqCmdRaw raw dq-axis current command
 * @param pidqCmd slew-rate limited dq-axis current command
 */
inline void MCAF_RateLimitCurrentCommand(const MC_DQ_T *pidqCmdRaw, MC_DQ_T *pidqCmd)
{
    /* Placeholder method. For now, just copy. */
    pidqCmd->d = pidqCmdRaw->d;
    pidqCmd->q = pidqCmdRaw->q;
}

/**
 * Executes one PI iteration for the current and velocity loops
 * 
 * @param pmotor motor state data
 */
void MCAF_VelocityAndCurrentControllerStep(MCAF_MOTOR_DATA *pmotor)
{
    /*
     * Check to see if new velocity information is available by comparing
     * the number of interrupts per velocity calculation against the
     * number of velocity count samples taken.  If new velocity info
     * is available, calculate the new velocity value and execute
     * the speed control loop.
     */

    if (pmotor->subsampleCounter == 0)
    {
        /*
         * Execute the velocity control loop
         */
        pmotor->omegaElectrical = pmotor->estimator.omega;
        
        const bool executeVelocityControlLoop =
            MCAF_OperatingModeNormal(&pmotor->testing) && pmotor->startup.complete;

        if (executeVelocityControlLoop)
        {
            const int16_t velocityCmdPerturbed = 
                  pmotor->velocityControl.velocityCmd
                + MCAF_TestPerturbationVelocity(&pmotor->testing);

            pmotor->velocityControl.velocityCmdRateLimited =
                UTIL_LimitSlewRateSymmetrical(
                    velocityCmdPerturbed,                /* input */
                    pmotor->omegaElectrical,             /* reference used as previousOutput */
                    pmotor->velocityControl.slewRateLimit1); /* slew rate limit */

            int16_t limitPos, limitNeg;
            if (pmotor->ui.direction > 0)
            {
                limitPos = pmotor->velocityControl.slewRateLimitAccel;
                limitNeg = pmotor->velocityControl.slewRateLimitDecel;
            }
            else
            {
                limitPos = pmotor->velocityControl.slewRateLimitDecel;
                limitNeg = pmotor->velocityControl.slewRateLimitAccel;
            }
            pmotor->omegaCmd =
                UTIL_LimitSlewRate(
                    pmotor->velocityControl.velocityCmdRateLimited, /* input */
                    pmotor->omegaCmd,                             /* previousOutput */
                    limitPos,   /* positive limit */
                    limitNeg);  /* negative limit */
        
            MCAF_ControllerPIUpdate(
                pmotor->omegaCmd,
                pmotor->omegaElectrical,
                &pmotor->omegaCtrl,
                pmotor->sat.state,
                &pmotor->idqCmdRaw.q,
                pmotor->ui.direction);
        
            /* 
             * Field weakening would go here
             */
            pmotor->idqCmdRaw.d = 0;
        }
    }

    if (MCAF_OperatingModeCurrentLoopActive(&pmotor->testing))
    {
        pmotor->idqCmdPerturbed.q = 
                  pmotor->idqCmdRaw.q
                + MCAF_TestPerturbationIq(&pmotor->testing);
        pmotor->idqCmdPerturbed.d = 
                  pmotor->idqCmdRaw.d
                + MCAF_TestPerturbationId(&pmotor->testing);
        
        MCAF_RateLimitCurrentCommand(&pmotor->idqCmdPerturbed, &pmotor->idqCmd);

        const int16_t vlim_d = UTIL_MulQ15(pmotor->idqCtrlOutLimit.d,
                                           pmotor->psys->vDC);
        pmotor->idCtrl.outMax =  vlim_d;
        pmotor->idCtrl.outMin = -vlim_d;
        /* PI control for D-axis */
        MCAF_ControllerPIUpdate(
                pmotor->idqCmd.d, 
                pmotor->idq.d, 
                &pmotor->idCtrl,
                MCAF_SAT_NONE, 
                &pmotor->vdqCmd.d,
                pmotor->ui.direction);

        pmotor->vdq.d = pmotor->vdqCmd.d;

        if (MCAF_OverrideDAxisVoltagePriority(&pmotor->testing))
        {
            /*
             * Vector limitation
             * Vd is not limited
             * Vq is limited so the vector Vs is less than a specified maximum.
             * Vs = SQRT(Vd^2 + Vq^2) < VDQ_SQUARED_LIMIT
             * Vq = SQRT(VDQ_SQUARED_LIMIT - Vd^2)
             * 
             * here VDQ_SQUARED_LIMIT is calculated as
             * Vdc * MCAF_CURRENT_CTRL_DQ_MAGNITUDE_LIMIT
             */
            const int16_t vdSquared = UTIL_SignedSqr(pmotor->vdq.d);
            const int16_t vdqSquaredLimit = UTIL_SignedSqr(UTIL_MulQ15(pmotor->psys->vDC, MCAF_CURRENT_CTRL_DQ_MAGNITUDE_LIMIT));
            pmotor->iqCtrl.outMax = Q15SQRT(vdqSquaredLimit - vdSquared);
            pmotor->iqCtrl.outMin = -pmotor->iqCtrl.outMax;
        }
        else
        {
            const int16_t vlim_q = UTIL_MulQ15(pmotor->idqCtrlOutLimit.q,
                                               pmotor->psys->vDC);            
            pmotor->iqCtrl.outMax =  vlim_q;
            pmotor->iqCtrl.outMin = -vlim_q;
        }

        /* PI control for Q-axis */
        MCAF_ControllerPIUpdate(
                pmotor->idqCmd.q,
                pmotor->idq.q,
                &pmotor->iqCtrl,
                MCAF_SAT_NONE, 
                &pmotor->vdqCmd.q,
                pmotor->ui.direction);

        pmotor->vdq.q = pmotor->vdqCmd.q;        
    } /* end of OM_FORCE_CURRENT section */
    else  /* in raw Vd, Vq mode */
    {
        pmotor->vdq.q = pmotor->vdqCmd.q 
                + MCAF_TestPerturbationVq(&pmotor->testing);
        pmotor->vdq.d = pmotor->vdqCmd.d
                + MCAF_TestPerturbationVd(&pmotor->testing);
    }

    MCAF_SatDetect(&pmotor->sat, &pmotor->idq, &pmotor->vdq, pmotor->psys->vDC);
}

/*
 * 3. Forward modulation path
 */

inline void MCAF_ApplyDCLinkVoltageCompensation(const MC_ABC_T *pvabc, MC_ABC_T *pdabc, int16_t rVdc, int16_t rVdc_q)
{
    pdabc->a = (int16_t) (UTIL_mulss(pvabc->a, rVdc) >> rVdc_q);
    pdabc->b = (int16_t) (UTIL_mulss(pvabc->b, rVdc) >> rVdc_q);
    pdabc->c = (int16_t) (UTIL_mulss(pvabc->c, rVdc) >> rVdc_q);
}

inline int16_t MCAF_ComputeReciprocalDCLinkVoltage(int16_t vdc)
{
    if (vdc <= MCAF_RVDC_MIN_VDC)
    {
        return MCAF_RVDC_MIN;
    }
    else
    {
        return __builtin_divf(MCAF_RVDC_MIN_VDC, vdc);
    }
}

static inline int16_t mulus16(uint16_t a, int16_t b)
{
    return __builtin_mulus(a,b) >> 16;
}

inline void MCAF_ComputeVAlphaBetaAtOutput(const MC_ABC_T *pdabc, 
                                            MC_ALPHABETA_T *pvalphabeta,
                                            int16_t vDC)
{
    MC_TransformClarkeABC(pdabc, pvalphabeta);
    pvalphabeta->alpha = UTIL_MulQ15(pvalphabeta->alpha, vDC);
    pvalphabeta->beta  = UTIL_MulQ15(pvalphabeta->beta,  vDC);
}

inline static void MCAF_ScaleQ15(const MC_ABC_T *pabc_in, MC_ABC_T *pabc_out, int16_t k)
{
    pabc_out->a = UTIL_MulQ15(pabc_in->a, k);
    pabc_out->b = UTIL_MulQ15(pabc_in->b, k);
    pabc_out->c = UTIL_MulQ15(pabc_in->c, k);
}

void MCAF_FocStepIsrForwardPath(MCAF_MOTOR_DATA *pmotor)
{
    /* Calculate control values */
    MCAF_VelocityAndCurrentControllerStep(pmotor);

    /* Calculate vAlpha, Vbeta from Sine, Cosine, Vd and Vq */
    MC_TransformParkInverse(&pmotor->vdq, &pmotor->sincos, &pmotor->valphabeta);

    /* Calculate Va,Vb,Vc from vAlpha and Vbeta */
    MC_TransformClarkeInverse(&pmotor->valphabeta, &pmotor->vabc);
    
    MCAF_ApplyDCLinkVoltageCompensation(&pmotor->vabc, &pmotor->dabcUnshifted, pmotor->rVdc, MCAF_RVDC_Q);
    
    /* Calculate scaled PWM duty cycles from Va,Vb,Vc and PWM period */
    MC_CalculateZeroSequenceModulation(&pmotor->dabcUnshifted,
        &pmotor->dabc,
        HAL_PARAM_MIN_DUTY_Q15, HAL_PARAM_MAX_DUTY_Q15);
    MCAF_ScaleQ15(&pmotor->dabc, (MC_ABC_T *)&pmotor->pwmDutycycle, 
        HAL_PARAM_PWM_PERIOD_COUNTS);
    
    MCAF_ComputeVAlphaBetaAtOutput(&pmotor->dabc, &pmotor->valphabetaOut, pmotor->psys->vDC);
}

/*
 * 4. Non-critical tasks
 */

void MCAF_FocStepIsrNonCriticalTask(MCAF_MOTOR_DATA* pmotor)
{
    if (!MCAF_OverrideDCLinkCompensation(&pmotor->testing))
    {
        pmotor->rVdc = MCAF_ComputeReciprocalDCLinkVoltage(pmotor->psys->vDC);
    }

    if (++pmotor->subsampleCounter >= MCAF_ISR_SUBSAMPLE_DIVIDER)
    {
        pmotor->subsampleCounter = 0;
    }
}

/*
 * 5. Miscellaneous
 */

void MCAF_FocStepMain(MCAF_MOTOR_DATA *pmotor)
{
    /* do nothing for now */
}

