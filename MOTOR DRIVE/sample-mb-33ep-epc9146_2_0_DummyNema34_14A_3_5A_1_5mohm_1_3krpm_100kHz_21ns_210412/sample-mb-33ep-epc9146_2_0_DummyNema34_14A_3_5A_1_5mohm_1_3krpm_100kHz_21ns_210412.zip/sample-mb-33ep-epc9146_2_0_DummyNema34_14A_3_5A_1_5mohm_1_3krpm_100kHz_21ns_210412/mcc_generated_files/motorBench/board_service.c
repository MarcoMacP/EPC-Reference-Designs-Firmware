/**
 * board_service.c
 * 
 * Provides hardware-independent board service components with interfaces
 * extending into the HAL.
 * 
 * Component: HAL
 */

/* *********************************************************************
 * 
 * Motor Control Application Framework
 * R5/RC11 (commit 98456, build on 2020 Feb 07)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#include <stdbool.h>
#include "board_service.h"
#include "error_codes.h"
#include "ui.h"
#include "parameters/hal_params.h"

inline static void MCAF_BoardProcessRun(MCAF_BOARD_DATA *);

void MCAF_BoardConfigure(MCAF_BOARD_DATA *pBoard)
{
    pBoard->configComplete = false;
    pBoard->runtimeState = HAL_BOARD_NOT_READY;
    pBoard->isrCount = 0;
    
    HAL_BoardTimer_Start();
     
    while (true)        // wait in this loop until the board is ready
    {
        while (HAL_BoardTimer_NotReady())
        {
            // do nothing
        }
        MCAF_BoardProcessRun(pBoard);
        if (pBoard->runtimeState == HAL_BOARD_READY)
        {
            HAL_BoardTimer_Stop();
            break;
        }
        else if (pBoard->runtimeState == HAL_BOARD_ERROR)
        {
            MCAF_UiFlashErrorCodeForever(ERR_BOARD_CONFIG_FAIL);
        }
    }
}

void MCAF_BoardService(MCAF_BOARD_DATA *pBoard)
{
    /* Execute board service process once every MCAF_BOARDSERVICE_ISR_PRESCALER
     * number of times the clocking ISR is executed */
    if (pBoard->isrCount >= MCAF_BOARDSERVICE_ISR_PRESCALER)
    {
        pBoard->isrCount = 0;
        
        MCAF_BoardProcessRun(pBoard);
        HAL_Button_Service();
        
        if (pBoard->runtimeState==HAL_BOARD_ERROR)
        {
            MCAF_UiFlashErrorCodeForever(ERR_BOARD_FAULT);
        }
    }
}

/**
 * This is a private function for this module. This function runs one step of the 
 * board process - i.e. either board configuration or board service routine, depending
 * on the state of pBoard->ConfigComplete flag.
 * @param pBoard pointer to the board data
 */
inline static void MCAF_BoardProcessRun(MCAF_BOARD_DATA *pBoard)
{
    if (!pBoard->configComplete)
    {
        pBoard->runtimeState = HAL_Board_Configure();
        if(pBoard->runtimeState == HAL_BOARD_READY)
        {
            pBoard->configComplete = true;
        }
    }
    else
    {
        pBoard->runtimeState  = HAL_Board_Service();
    }    
}

void MCAF_BoardServiceStepIsr(MCAF_BOARD_DATA *pBoard)
{
    pBoard->isrCount++;
}

void MCAF_BootstrapChargeInitialize(MCAF_BOARD_DATA *pBoard)
{
    pBoard->bootstrapDutycycle[0] = 0;
    pBoard->bootstrapDutycycle[1] = 0;
    pBoard->bootstrapDutycycle[2] = 0;
    pBoard->delayCount = 0;
    pBoard->bootstrapState = 0;
}

bool MCAF_BootstrapChargeExecute(MCAF_BOARD_DATA *pBoard)
{
    bool returnState = false;
    
    switch(pBoard->bootstrapState)
    {
        case MCBS_IDLE_START:
            HAL_PWM_Outputs_Disable();
            pBoard->bootstrapDutycycle[0] = HAL_PARAM_PWM_PERIOD_COUNTS;
            pBoard->bootstrapDutycycle[1] = HAL_PARAM_PWM_PERIOD_COUNTS;
            pBoard->bootstrapDutycycle[2] = HAL_PARAM_PWM_PERIOD_COUNTS;
            pBoard->delayCount = MCAF_BOARD_BOOTSTRAP_INITIAL_DELAY;
            pBoard->bootstrapState = MCBS_WAIT0;
            break;
            
        case MCBS_WAIT0:
            /* Wait for a preset duration of time */
            if (pBoard->delayCount == 0)
            {
                /* Override all three motor phases to LOW state and
                 * reset all bootstrap related state variables */
                HAL_PWM_UpperTransistorsOverride_Low();
                HAL_PWM_LowerTransistorsOverride_Disable();                
                
                pBoard->bootstrapState = MCBS_PHASE_A_CHARGING;
            }
            break;

        case MCBS_PHASE_A_CHARGING:
            /* Increment the phase duty cycle at a controlled rate till
             * it reaches a preset value and then proceed to the next state */
            if (pBoard->delayCount == 0)
            {
                pBoard->delayCount = MCAF_BOARD_BOOTSTRAP_SEQUENCE_DELAY;
                if (pBoard->bootstrapDutycycle[0] > (HAL_PARAM_PWM_PERIOD_COUNTS-HAL_PARAM_MIN_LOWER_DUTY_COUNTS))
                {
                    pBoard->bootstrapDutycycle[0]--;
                }
                else
                {
                    pBoard->delayCount = MCAF_BOARD_BOOTSTRAP_PHASE_DELAY;
                    pBoard->bootstrapState = MCBS_WAIT1;
                }
            }
            break;
            
        case MCBS_WAIT1:
            /* Wait for a preset duration of time */
            if (pBoard->delayCount == 0)
            {
                pBoard->bootstrapState = MCBS_PHASE_B_CHARGING;
            }
            break;
            
        case MCBS_PHASE_B_CHARGING:
            /* Increment the phase duty cycle at a controlled rate till
             * it reaches a preset value and then proceed to the next state */            
            if (pBoard->delayCount == 0)
            {
                pBoard->delayCount = MCAF_BOARD_BOOTSTRAP_SEQUENCE_DELAY;
                if (pBoard->bootstrapDutycycle[1] > (HAL_PARAM_PWM_PERIOD_COUNTS-HAL_PARAM_MIN_LOWER_DUTY_COUNTS))
                {
                    pBoard->bootstrapDutycycle[1]--;
                }
                else
                {
                    pBoard->delayCount = MCAF_BOARD_BOOTSTRAP_PHASE_DELAY;
                    pBoard->bootstrapState = MCBS_WAIT2;
                }
            }
            break;
            
        case MCBS_WAIT2:
            /* Wait for a preset duration of time */
            if (pBoard->delayCount == 0)
            {
                pBoard->bootstrapState = MCBS_PHASE_C_CHARGING;
            }
            break;

        case MCBS_PHASE_C_CHARGING:
            /* Increment the phase duty cycle at a controlled rate till
             * it reaches a preset value and then proceed to the next state */            
            if (pBoard->delayCount == 0)
            {
                pBoard->delayCount = MCAF_BOARD_BOOTSTRAP_SEQUENCE_DELAY;
                if (pBoard->bootstrapDutycycle[2] > (HAL_PARAM_PWM_PERIOD_COUNTS-HAL_PARAM_MIN_LOWER_DUTY_COUNTS))
                {
                    pBoard->bootstrapDutycycle[2]--;
                }
                else
                {
                    pBoard->bootstrapState = MCBS_BOOTSTRAP_COMPLETE;
                }
            }
            break;
            
        case MCBS_BOOTSTRAP_COMPLETE:
            /* Bootstap sequence is complete, wait in this state */
            returnState = true;
            break;
    }
    HAL_PWM_DutyCycle_Set(pBoard->bootstrapDutycycle);
    
    if (pBoard->delayCount > 0)
    {
        pBoard->delayCount--;
    }
    
    return returnState;
}