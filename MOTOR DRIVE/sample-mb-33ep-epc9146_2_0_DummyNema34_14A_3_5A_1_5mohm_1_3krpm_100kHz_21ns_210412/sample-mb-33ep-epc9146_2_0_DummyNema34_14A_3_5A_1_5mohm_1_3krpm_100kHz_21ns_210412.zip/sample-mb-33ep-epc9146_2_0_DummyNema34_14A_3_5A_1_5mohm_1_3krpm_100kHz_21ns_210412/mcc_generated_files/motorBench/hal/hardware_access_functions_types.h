/**
  @File Name:
    hardware_access_functions_types.h

  @Summary:
    This file includes type defines for the hardware access function module.

  @Description:
    This file includes type defines for the hardware access function module.
 */
/* ********************************************************************
 * Motor Control Application Framework
 * R5/RC11 (commit 98456, build on 2020 Feb 07)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
* *****************************************************************************/

#ifndef __HAF_TYPES_H
#define __HAF_TYPES_H

#include <stdbool.h>
#include <stdint.h>


/******************************************************************************/
/* Section: Public type defines                                               */										
/******************************************************************************/

typedef enum tagHAL_BOARD_STATUS
{ 
    /** Board is not ready */
    HAL_BOARD_NOT_READY = 0,  
    /** Board error */
    HAL_BOARD_ERROR = 1,
    /** Board is busy, try again later */
    HAL_BOARD_BUSY = 3,
    /** Board ready/OK */
    HAL_BOARD_READY = 4
} HAL_BOARD_STATUS;

typedef enum tagHAL_BUTTON_STATE
{
    HAL_BUTTON_STATE_WAIT = 0,           // wait till button not pressed for sometime
    HAL_BUTTON_STATE_IDLE = 1,           // wait for button to be pressed
    HAL_BUTTON_STATE_BUTTON_PRESSED = 2, // button was pressed, check if short press / long press
    HAL_BUTTON_STATE_LONG_PRESS = 3,     // it was long press, pulse longButtonPress flag
    HAL_BUTTON_STATE_SHORT_PRESS = 4     // it was short press, pulse shortButtonPress flag
} HAL_BUTTON_STATE;
    
typedef struct tagHAL_BUTTON_DATA_T
{ 
    HAL_BUTTON_STATE buttonState;   // button state machine
    bool shortButtonPress;          // button flag
    bool longButtonPress;           // button flag
    uint16_t buttonPressCounter;    // used to measure button press duration
    uint16_t holdOffCounter;        // used for debounce delay, pulse duration
} HAL_BUTTON_DATA_T;

typedef struct tagHAL_DATA_T
{
    HAL_BUTTON_DATA_T sw1;
    HAL_BUTTON_DATA_T sw2;
} HAL_DATA_T;

typedef enum tagHAL_ADC_SELECT_T
{
    HADC_POTENTIOMETER = 0,
    HADC_VDC           = 1
} HAL_ADC_SELECT_T;

#endif /* __HAF_TYPES_H */
