/**
 *   hardware_access_functions.h
 *
 *  This module provides hardware access function support.
 *
 *  Component: Hardware Access Functions
 */
 
/*
 *
 * Motor Control Application Framework
 * R5/RC11 (commit 98456, build on 2020 Feb 07)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 *
 ******************************************************************************/
 
#ifndef __HAF_H
#define __HAF_H

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include "bsp.h"
#include "hardware_access_functions_types.h"
#include "hardware_access_functions_params.h"
#include "bsp_led_gp1.h" //Must include this before pin_manager.h (CC16BOARD-234)
#include "bsp_led_gp2.h"
#include "bsp_button_gp1.h"
#include "bsp_button_gp2.h"
#include "mcc.h"
#include "adc1.h"
#include "pwm_module_features.h"
#include "adc_module_features.h"


#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif

// This is the instruction cycle frequency required for libpic30.h
#define FCY  CLOCK_InstructionFrequencyGet()

/**
  Section: Traps helper macros
 */
    
#define HAL_OSCFAIL_TRAP_FUNCTION        _OscillatorFail
#define HAL_ADDRESSERROR_TRAP_FUNCTION   _AddressError
#define HAL_STACKERROR_TRAP_FUNCTION     _StackError
#define HAL_MATHERROR_TRAP_FUNCTION      _MathError

/**
  Section: ISR helper macros
 */
    
#define HAL_ADC_ISR            _AD1Interrupt
#define HAL_DMA0_ISR            _DMA0Interrupt
#define HAL_DMA1_ISR            _DMA1Interrupt
#define HAL_PWM1_ISR            _PWM1Interrupt
#define HAL_PWM2_ISR            _PWM2Interrupt
#define HAL_UART1_RXISR         _U1RXInterrupt
#define HAL_UART1_TXISR         _U1TXInterrupt
#define HAL_UART2_RXISR			_U2RXInterrupt
#define HAL_UART2_TXISR 		_U2TXInterrupt
#define HAL_PWM4_ISR            _PWM4Interrupt
#define HAL_PWM5_ISR            _PWM5Interrupt
#define HAL_TIMER1_ISR          _T1Interrupt
#define HAL_TIMER2_ISR          _T2Interrupt


/**
  Section: Hardware Access Functions
 */     

/**
  Sub-section: PWM Module Access Functions
*/

/**
 * Enables the PWM module.
 * Summary: Enables the whole of the PWM module.
 * @example
 * <code>
 * HAL_PWM_ModuleEnable();
 * </code>
 */
inline static void HAL_PWM_ModuleEnable(void) { PWM_Enable(); }

/**
 * Sets the master period cycle for all PWM to synchronize.
 * @param period PWM period value
 * @example
 * <code>
 * HAL_PWM_MasterPeriodSet(3500);
 * </code>
 */
inline static void HAL_PWM_MasterPeriodSet(uint16_t period) { PWM_MasterPeriodSet(period); }

/**
 * Sets identical PWM period values for Centeraligned PWM mode on all three phases of Motor #1.
 * @param period PWM period value
 * @example
 * <code>
 * HAL_PWM_SetPeriodIdentical_Motor1(3500);
 * </code>
 */
inline static void HAL_PWM_SetPeriodIdentical_Motor1(uint16_t period)
{
    PWM_PeriodSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,period);
    PWM_PeriodSet(BSP_MOTOR1_PHASEB_PWMCHANNEL,period);
    PWM_PeriodSet(BSP_MOTOR1_PHASEC_PWMCHANNEL,period);
}

/**
 * Sets identical PWM deadtime values for Centeraligned PWM mode on all three phases of Motor #1.
 * @param dt PWM deadtime value
 * @example
 * <code>
 * HAL_PWM_SetDeadtimeIdentical_Motor1(140);
 * </code>
 */
inline static void HAL_PWM_SetDeadtimeIdentical_Motor1(uint16_t dt)
{
    PWM_DeadTimeSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,dt);
    PWM_DeadTimeSet(BSP_MOTOR1_PHASEB_PWMCHANNEL,dt);
    PWM_DeadTimeSet(BSP_MOTOR1_PHASEC_PWMCHANNEL,dt);
}

/**
 * Clears the PWM fault interrupt status for Motor #1.
 * @example
 * <code>
 * HAL_PWM_FaultStatus_Clear();
 * </code>
 */
inline static void HAL_PWM_FaultStatus_Clear(void)
{
    PWM_GeneratorEventStatusClear(BSP_MOTOR1_PHASEA_PWMCHANNEL, PWM_GENERATOR_INTERRUPT_FAULT);
}

/**
 * Gets the status of PWM fault interrupt for Motor #1.
 * @example
 * <code>
 * HAL_PWM_FaultStatus_Get();
 * </code>
 */
inline static bool HAL_PWM_FaultStatus_Get(void)
{
    return PWM_GeneratorEventStatusGet(BSP_MOTOR1_PHASEA_PWMCHANNEL,PWM_GENERATOR_INTERRUPT_FAULT);
}

/**
 * Sets up the trigger generator for PWM channel correlated to Motor #1 phase-A and enables the
 * corresponding trigger interrupt source. The trigger source is setup such that it generates two
 * trigger events with zero start delay occurring every Centeraligned PWM period, with timing that
 * is dependent on the trigger value.
 * @param triggerValue PWM count trigger match value
 * @example
 * <code>
 * HAL_PWM_PhaseATriggerGenerator_Set(3400);
 * </code>
 */
inline static void HAL_PWM_PhaseATriggerGenerator_Set(uint16_t triggerValue)
{
    #if (PWM_MULTIPLE_TRIGGER_FEATURE_AVAILABLE)
        ;// Do nothing
    #else
    PWM_TriggerCompareValueSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,triggerValue);
    PWM_GeneratorInterruptEnable(BSP_MOTOR1_PHASEA_PWMCHANNEL,PWM_GENERATOR_INTERRUPT_TRIGGER);
    #endif
}

/**
 * Disables PWM override on the three low-side transistors for Motor #1.
 * Summary: Disables PWM override on the three low-side transistors for Motor #1.
 * @example
 * <code>
 * HAL_PWM_LowerTransistorsOverride_Disable();
 * </code>
 */
inline static void HAL_PWM_LowerTransistorsOverride_Disable(void)
{
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
}

/**
 * Enables PWM override to state LOW on the three low-side transistors for Motor #1.
 * Summary: Enables PWM override to state LOW on the three low-side transistors for Motor #1.
 * @example
 * <code>
 * HAL_PWM_LowerTransistorsOverride_Low();
 * </code>
 */
inline static void HAL_PWM_LowerTransistorsOverride_Low(void)
{
    /* Set PWM override data to 0b00 */
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,0);
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEB_PWMCHANNEL,0);
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEC_PWMCHANNEL,0);
    
    /* Enable PWM override */    
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
}

    
/**
 * Disables PWM override on the three high-side transistors for Motor #1.
 * Summary: Disables PWM override on the three high-side transistors for Motor #1.
 * @example
 * <code>
 * HAL_PWM_UpperTransistorsOverride_Disable();
 * </code>
 */
inline static void HAL_PWM_UpperTransistorsOverride_Disable(void)
{
    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
}

/**
 * Enables PWM override to state LOW on the three high-side transistors for Motor #1.
 * Summary: Enables PWM override to state LOW on the three high-side transistors for Motor #1.
 * @example
 * <code>
 * HAL_PWM_UpperTransistorsOverride_Low();
 * </code>
 */
inline static void HAL_PWM_UpperTransistorsOverride_Low(void)
{
    /* Set PWM override data to 0b00 */
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,0);
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEB_PWMCHANNEL,0);
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEC_PWMCHANNEL,0);

    /* Enable PWM override */
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
}

/**
 * Sets identical duty cycle values on three phases of Motor #1.
 * Summary: Sets identical duty cycle values on three phases of Motor #1.
 * @param dc Duty cycle value
 * @example
 * <code>
 * HAL_PWM_DutyCycle_SetIdentical(500);
 * </code>
 */
inline static void HAL_PWM_DutyCycle_SetIdentical(uint16_t dc)
{
    PWM_DutyCycleSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,dc);
    PWM_DutyCycleSet(BSP_MOTOR1_PHASEB_PWMCHANNEL,dc);
    PWM_DutyCycleSet(BSP_MOTOR1_PHASEC_PWMCHANNEL,dc);
}

/**
 * Writes three unique duty cycle values to the PWM duty cycle registers
 * corresponding to Motor #1.
 * Summary: Writes to the PWM duty cycle registers corresponding to Motor #1.
 * @param pdc Pointer to the array that holds duty cycle values
 * @example
 * <code>
 * HAL_PWM_DutyCycle_Set(&pdcMotor1);
 * </code>
 */
inline static void HAL_PWM_DutyCycle_Set(const uint16_t *pdc)
{
    PWM_DutyCycleSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,pdc[0]);
    PWM_DutyCycleSet(BSP_MOTOR1_PHASEB_PWMCHANNEL,pdc[1]);
    PWM_DutyCycleSet(BSP_MOTOR1_PHASEC_PWMCHANNEL,pdc[2]);
}

/**
* Begins the PWM fault clearing process for all PWM instances 
* Summary: Begins fault clearing process.
* <code>
* HAL_PWM_FaultClearBegin();
* </code>
*/
inline static void HAL_PWM_FaultClearBegin(void)
{
    #if (PWM_FAULT_LATCH_SOFTWARE_CLEAR_FEATURE_AVAILABLE)
    {
        PWM_FaultModeLatchClear(BSP_MOTOR1_PHASEA_PWMCHANNEL);
        PWM_FaultModeLatchClear(BSP_MOTOR1_PHASEB_PWMCHANNEL);
        PWM_FaultModeLatchClear(BSP_MOTOR1_PHASEC_PWMCHANNEL);
    }
    #else
    {
        PWM_FaultModeLatchDisable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
        PWM_FaultModeLatchDisable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
        PWM_FaultModeLatchDisable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
    }
    #endif
}

/**
* Ends the PWM fault clearing process for all PWM instances 
* Summary: Ends fault clearing process.
* <code>
* HAL_PWM_FaultClearEnd();
* </code>
*/
inline static void HAL_PWM_FaultClearEnd(void)
{
    #if (PWM_FAULT_LATCH_SOFTWARE_CLEAR_FEATURE_AVAILABLE)
    {
        ; // no action required
    }
    #else
    {
        PWM_FaultModeLatchEnable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
        PWM_FaultModeLatchEnable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
        PWM_FaultModeLatchEnable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
    }
    #endif
}


/**
 * Maintains the Motor #1 low-side transistors at the requested duty cycle while
 * keeping high-side transistors OFF.
 * Summary: Maintains the Motor #1 PWM outputs to an idle state with minimal impact to the motor.
 * @param pwmPeriodCount PWM period count
 * @param dc Duty cycle value for the low-side transistors
 * @example
 * <code>
 * HAL_PWM_LowerTransistorsDutyCycle_Set(3500,220);
 * </code>
 */
inline static void HAL_PWM_LowerTransistorsDutyCycle_Set(uint16_t pwmPeriodCount, uint16_t dc)
{
    HAL_PWM_UpperTransistorsOverride_Low();

    uint16_t dutyCycleLowSide = pwmPeriodCount;
    dutyCycleLowSide -= dc;

    HAL_PWM_DutyCycle_SetIdentical(dutyCycleLowSide);
}

/**
 * Disable the PWM channels assigned for Motor #1 by overriding them to low state.
 * Summary: Disable the PWM channels assigned for Motor #1 by overriding them to low state.
 * @example
 * <code>
 * HAL_PWM_Outputs_Disable();
 * </code>
 */
inline static void HAL_PWM_Outputs_Disable(void)
{
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,0);
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEB_PWMCHANNEL,0);
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEC_PWMCHANNEL,0);   
    
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEA_PWMCHANNEL);    
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEB_PWMCHANNEL);    
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEC_PWMCHANNEL);    
}

/**
 * Disable the PWM channels assigned for Phase-A of Motor #1 by overriding them to low state.
 * Summary: Disable the PWM channels assigned for Phase-A of Motor #1 by overriding them to low state.
 * @example
 * <code>
 * HAL_PWM_PhaseAOutput_Disable();
 * </code>
 */
inline static void HAL_PWM_PhaseAOutput_Disable(void)
{
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEA_PWMCHANNEL,0);  
    
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
}

/**
 * Enable the PWM channels assigned for Phase-A of Motor #1.
 * Summary: Enable the PWM channels assigned for Phase-A of Motor #1.
 * @example
 * <code>
 * HAL_PWM_PhaseAOutput_Enable();
 * </code>
 */
inline static void HAL_PWM_PhaseAOutput_Enable(void)
{
    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
}

/**
 * Disable the PWM channels assigned for Phase-B of Motor #1 by overriding them to low state.
 * Summary: Disable the PWM channels assigned for Phase-B of Motor #1 by overriding them to low state.
 * @example
 * <code>
 * HAL_PWM_PhaseBOutput_Disable();
 * </code>
 */
inline static void HAL_PWM_PhaseBOutput_Disable(void)
{
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEB_PWMCHANNEL,0);
    
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
}

/**
 * Enable the PWM channels assigned for Phase-B of Motor #1.
 * Summary: Enable the PWM channels assigned for Phase-B of Motor #1.
 * @example
 * <code>
 * HAL_PWM_PhaseBOutput_Enable();
 * </code>
 */
inline static void HAL_PWM_PhaseBOutput_Enable(void)
{
    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
}

/**
 * Disable the PWM channels assigned for Phase-C of Motor #1 by overriding them to low state.
 * Summary: Disable the PWM channels assigned for Phase-C of Motor #1 by overriding them to low state.
 * @example
 * <code>
 * HAL_PWM_PhaseCOutput_Disable();
 * </code>
 */
inline static void HAL_PWM_PhaseCOutput_Disable(void)
{
    PWM_OverrideDataSet(BSP_MOTOR1_PHASEC_PWMCHANNEL,0);
    
    PWM_OverrideHighEnable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
    PWM_OverrideLowEnable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
}

/**
 * Enable the PWM channels assigned for Phase-C of Motor #1.
 * Summary: Enable the PWM channels assigned for Phase-C of Motor #1.
 * @example
 * <code>
 * HAL_PWM_PhaseCOutput_Enable();
 * </code>
 */
inline static void HAL_PWM_PhaseCOutput_Enable(void)
{
    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
}

/**
 * Enables the PWM channels assigned for Motor #1 by disabling the PWM override function.
 * Summary: Enables the PWM channels assigned for Motor #1 by disabling the PWM override function.
 * @example
 * <code>
 * HAL_PWM_Outputs_Enable();
 * </code>
 */
inline static void HAL_PWM_Outputs_Enable(void)
{
    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEA_PWMCHANNEL);
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEA_PWMCHANNEL);

    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEB_PWMCHANNEL);
    
    PWM_OverrideHighDisable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
    PWM_OverrideLowDisable(BSP_MOTOR1_PHASEC_PWMCHANNEL);
}

/**
  Sub-section: GPIO Module Access Functions
*/

/**
 * Configures the board and initializes any state depenendent data that is used
 * in the HAL. This function needs to be called once every 1ms.
 * Summary: Configures the board and initializes any state depenendent data that is used in the HAL.
 * @example
 * <code>
 * while (HAL_Board_Configure()==HAL_BOARD_NOT_READY);
 * <code>
 */
HAL_BOARD_STATUS HAL_Board_Configure(void);

/**
 * Runs the board service routines. This function needs to be called once every 1ms.
 * Summary: Runs the board service routines.
 * @example
 * <code>
 * if (HAL_Board_Service()!=HAL_BOARD_READY)
 * {
 *     // do something
 * }
 * <code>
 */
HAL_BOARD_STATUS HAL_Board_Service(void);

/**
 * Runs the button handler to check for short and long press events.
 * @param pButtonData pointer ot the button data structure
 * @param button GPIO access method for the given button
 */
inline static void HAL_Button_Check(volatile HAL_BUTTON_DATA_T *pButtonData, bool button)
{
    switch (pButtonData->buttonState)
    {
        case HAL_BUTTON_STATE_WAIT:
            if(!button)
            {
                if(pButtonData->holdOffCounter > 0)
                {
                    pButtonData->holdOffCounter--;
                }
                else
                {
                    pButtonData->buttonState = HAL_BUTTON_STATE_IDLE;
                }                
            }
            else
            {
                pButtonData->holdOffCounter = BSP_BUTTON_DEBOUNCE_DELAY_COUNT;
            }
            break;
        
        case HAL_BUTTON_STATE_IDLE:
            if(button)
            {
                pButtonData->buttonState = HAL_BUTTON_STATE_BUTTON_PRESSED;
            }
            break;
            
        case HAL_BUTTON_STATE_BUTTON_PRESSED:
            if(pButtonData->buttonPressCounter < BSP_EMULATED_BUTTON_DELAY_COUNT)
            {
                pButtonData->buttonPressCounter++;
                if(!button)
                {
                    pButtonData->buttonPressCounter = 0;
                    pButtonData->holdOffCounter = BSP_BUTTON_HOLDOFF_COUNT;
                    pButtonData->buttonState = HAL_BUTTON_STATE_SHORT_PRESS;
                }
            }
            else
            {
                if(button)
                {
                    pButtonData->buttonPressCounter = 0;
                    pButtonData->holdOffCounter = BSP_BUTTON_HOLDOFF_COUNT;
                    pButtonData->buttonState = HAL_BUTTON_STATE_LONG_PRESS;
                }
                else
                {
                    pButtonData->buttonPressCounter = 0;
                    pButtonData->holdOffCounter = BSP_BUTTON_HOLDOFF_COUNT;
                    pButtonData->buttonState = HAL_BUTTON_STATE_SHORT_PRESS;
                }
            }
            break;
            
        case HAL_BUTTON_STATE_SHORT_PRESS:
            if(pButtonData->holdOffCounter > 0)
            {
                pButtonData->holdOffCounter--;
                pButtonData->shortButtonPress = true;
            }
            else
            {
                pButtonData->shortButtonPress = false;
                pButtonData->holdOffCounter = BSP_BUTTON_DEBOUNCE_DELAY_COUNT;
                pButtonData->buttonState = HAL_BUTTON_STATE_WAIT;
            }
            break;
            
        case HAL_BUTTON_STATE_LONG_PRESS:
            if(pButtonData->holdOffCounter > 0)
            {
                pButtonData->holdOffCounter--;
                pButtonData->longButtonPress = true;
            }
            else
            {
                pButtonData->longButtonPress = false;
                pButtonData->holdOffCounter = BSP_BUTTON_DEBOUNCE_DELAY_COUNT;
                pButtonData->buttonState = HAL_BUTTON_STATE_WAIT;
            }
            break;
    }
    
}

/**
 * Executes the button handler service for all physical and emulated buttons.
 */
void HAL_Button_Service(void);

/**
 * Initializes the button handler service for all physical and emulatede buttons.
 */
void HAL_ButtonGroup_Initialize(void);

/**
 * Initializes the state variables for a given button.
 * @param pButtonData pointer to a HAL_BUTTON_DATA_T struct
 */
inline static void HAL_Button_Initialize(volatile HAL_BUTTON_DATA_T *pButtonData)
{
    pButtonData->buttonState = HAL_BUTTON_STATE_WAIT;
    pButtonData->shortButtonPress = 0;
    pButtonData->longButtonPress = 0;
    pButtonData->buttonPressCounter = 0;
    pButtonData->holdOffCounter = 0;
}

/**
 * Reads the state of Button-GP1 and returns it as a boolean state. When Button-GP1
 * is pressed, the state of Button-GP1 holds "true" momentarily before changing
 * back to "false" state. This duration of hold-off time is defined as a configurable
 * parameter in the HAF module. Hence, the application needs to call this function 
 * at least once every hold-off time period to avoid missing a button press event.
 * @return true = button was pressed, false = button was not pressed
 */
bool HAL_ButtonGp1_IsPressed(void);

/**
 * Reads the state of Button-GP2 and returns it as a boolean state. When Button-GP2
 * is pressed, the state of Button-GP2 holds "true" momentarily before changing
 * back to "false" state. This duration of hold-off time is defined as a configurable
 * parameter in the HAF module. Hence, the application needs to call this function 
 * at least once every hold-off time period to avoid missing a button press event.
 * @return true = button was pressed, false = button was not pressed
 */
bool HAL_ButtonGp2_IsPressed(void);

/**
 * Activates LED-GP1.
 * Summary: Activates LED-GP1.
 * @example
 * <code>
 * HAL_LedGp1_Activate();
 * </code>
 */
inline static void HAL_LedGp1_Activate(void) { BSP_LED_GP1_On(); }

/**
 * Deactivates LED-GP1.
 * Summary: Deactivates LED-GP1.
 * @example
 * <code>
 * HAL_LedGp1_Deactivate();
 * </code>
 */
inline static void HAL_LedGp1_Deactivate(void) { BSP_LED_GP1_Off(); }

/**
 * Activates LED-GP2.
 * Summary: Activates LED-GP2.
 * @example
 * <code>
 * HAL_LedGp2_Activate();
 * </code>
 */
inline static void HAL_LedGp2_Activate(void) { BSP_LED_GP2_On(); }

/**
 * Deactivates LED-GP2.
 * Summary: Deactivates LED-GP2.
 * @example
 * <code>
 * HAL_LedGp2_Deactivate();
 * </code>
 */
inline static void HAL_LedGp2_Deactivate(void) { BSP_LED_GP2_Off(); }

/**
 * Activates Testpoint-GP1.
 * Summary: Activates Testpoint-GP1.
 * @example
 * <code>
 * HAL_TestpointGp1_Activate();
 * </code>
 */
inline static void HAL_TestpointGp1_Activate(void) { BSP_TESTPOINT_GP1_SetHigh(); }

/**
 * Deactivates Testpoint-GP1.
 * Summary: Deactivates Testpoint-GP1.
 * @example
 * <code>
 * HAL_TestpointGp1_Deactivate();
 * </code>
 */
inline static void HAL_TestpointGp1_Deactivate(void) { BSP_TESTPOINT_GP1_SetLow(); }

/**
 * Activates Testpoint-GP2.
 * Summary: Activates Testpoint-GP2.
 * @example
 * <code>
 * HAL_TestpointGp2_Activate();
 * </code>
 */
inline static void HAL_TestpointGp2_Activate(void) { BSP_TESTPOINT_GP2_SetHigh(); }

/**
 * Deactivates Testpoint-GP2.
 * Summary: Deactivates Testpoint-GP2.
 * @example
 * <code>
 * HAL_TestpointGp2_Deactivate();
 * </code>
 */
inline static void HAL_TestpointGp2_Deactivate(void) { BSP_TESTPOINT_GP2_SetLow(); }

/**
 * Activates Testpoint-GP3.
 * Summary: Activates Testpoint-GP3.
 * @example
 * <code>
 * HAL_TestpointGp3_Activate();
 * </code>
 */
inline static void HAL_TestpointGp3_Activate(void) { }

/**
 * Deactivates Testpoint-GP3.
 * Summary: Deactivates Testpoint-GP3.
 * @example
 * <code>
 * HAL_TestpointGp3_Deactivate();
 * </code>
 */
inline static void HAL_TestpointGp3_Deactivate(void) { }

/**
 * Activates Testpoint-GP4.
 * Summary: Activates Testpoint-GP4.
 * @example
 * <code>
 * HAL_TestpointGp4_Activate();
 * </code>
 */
inline static void HAL_TestpointGp4_Activate(void) { BSP_TESTPOINT_GP4_SetHigh(); }

/**
 * Deactivates Testpoint-GP4.
 * Summary: Deactivates Testpoint-GP4.
 * @example
 * <code>
 * HAL_TestpointGp4_Deactivate();
 * </code>
 */
inline static void HAL_TestpointGp4_Deactivate(void) { BSP_TESTPOINT_GP4_SetLow(); }

/**
 * Activates Testpoint-GP5.
 * Summary: Activates Testpoint-GP5.
 * @example
 * <code>
 * HAL_TestpointGp5_Activate();
 * </code>
 */
inline static void HAL_TestpointGp5_Activate(void) { }

/**
 * Deactivates Testpoint-GP5.
 * Summary: Deactivates Testpoint-GP5.
 * @example
 * <code>
 * HAL_TestpointGp5_Deactivate();
 * </code>
 */
inline static void HAL_TestpointGp5_Deactivate(void) { }

/**
 * Activates Testpoint-GP6.
 * Summary: Activates Testpoint-GP6.
 * @example
 * <code>
 * HAL_TestpointGp6_Activate();
 * </code>
 */
inline static void HAL_TestpointGp6_Activate(void) { }

/**
 * Deactivates Testpoint-GP6.
 * Summary: Deactivates Testpoint-GP6.
 * @example
 * <code>
 * HAL_TestpointGp6_Deactivate();
 * </code>
 */
inline static void HAL_TestpointGp6_Deactivate(void) { }

/**
  Sub-section: ADC Module Access Functions
*/

/**
 * Get the ADC channel number corresponding to the potentiometer analog input for motor #1.
 * @return ADC channel number
 */
inline static uint16_t HAL_ADC_ChannelPotentiometer(void) { return MCAF_ADC_POTENTIOMETER; }

/**
 * Get the ADC channel number corresponding to the DC link voltage sense analog input for motor #1.
 * @return ADC channel number
 */
inline static uint16_t HAL_ADC_ChannelDclink(void) { return MCAF_ADC_DCLINK_VOLTAGE; }

/**
 * Get the ADC channel number corresponding to phase current A analog input for motor #1.
 * @return ADC channel number
 */
inline static uint16_t HAL_ADC_ChannelIphaseA(void) { return MCAF_ADC_PHASEA_CURRENT; }

/**
 * Get the ADC channel number corresponding to phase current B analog input for motor #1.
 * @return ADC channel number
 */
inline static uint16_t HAL_ADC_ChannelIphaseB(void) { return MCAF_ADC_PHASEB_CURRENT; }

/**
 * Get the ADC channel number corresponding to sum phase/DC link current analog input for motor #1.
 * @return ADC channel number
 */
inline static uint16_t HAL_ADC_ChannelIphaseSum(void) { return MCAF_ADC_SUMPHASE_CURRENT; }

/**
 * Get the ADC result corresponding to phase current A analog input for motor #1.
 * @return ADC result value
 */
inline static uint16_t HAL_ADC_ValueIphaseA(void) { return ADC1_ConversionResultGet(MCAF_ADC_PHASEA_CURRENT); }

/**
 * Get the ADC result corresponding to phase current B analog input for motor #1.
 * @return ADC result value
 */
inline static uint16_t HAL_ADC_ValueIphaseB(void) { return ADC1_ConversionResultGet(MCAF_ADC_PHASEB_CURRENT); }

/**
 * Get the ADC result corresponding to phase current C analog input for motor #1.
 * @return ADC result value
 */
inline static uint16_t HAL_ADC_ValueIphaseC(void) { return 0; }

/**
 * Get the ADC result corresponding to sum phase analog input for motor #1.
 * @return ADC result value
 */
inline static uint16_t HAL_ADC_ValueIphaseSum(void) { return ADC1_ConversionResultGet(MCAF_ADC_SUMPHASE_CURRENT); }

/**
 * Get the ADC result corresponding to potentiometer analog input for motor #1.
 * @return ADC result value
 */
inline static uint16_t HAL_ADC_ValuePotentiometer(void) { return ADC1_ConversionResultGet(MCAF_ADC_POTENTIOMETER); }

/**
 * Get the ADC result corresponding to DC link voltage sense analog input for motor #1.
 * @return ADC result value
 */
inline static uint16_t HAL_ADC_ValueDclink(void) { return ADC1_ConversionResultGet(MCAF_ADC_DCLINK_VOLTAGE); }

/**
* Enables the ADC module.
* Summary: Enables the whole of the ADC module.
* @example
* <code>
* HAL_ADC_Enable();
* </code>
*/
inline static void HAL_ADC_Enable(void) { ADC1_Enable(); }

/**
* Clears the ADC interrupt flag.
* @example
* <code>
* HAL_ADC_InterruptFlag_Clear();
* </code>
*/
inline static void HAL_ADC_InterruptFlag_Clear(void) 
{ 
    #if (ADC_INDIVIDUAL_CHANNEL_INTERRUPT_FEATURE_AVAILABLE)
        // In order to clear the ADC ISR flag one must read the associated
        // ADC buffer. This dummy read is to ensure the ISR flag will be cleared.
        ADC1_ConversionResultGet(MCAF_ADC_POTENTIOMETER);
        ADC1_IndividualChannelInterruptFlagClear(MCAF_ADC_POTENTIOMETER);
    #else
        ADC1_InterruptFlagClear();   
    #endif
}

/**
* Enables the ADC interrupt flag.
* @example
* <code>
* HAL_ADC_Interrupt_Enable();
* </code>
*/
inline static void HAL_ADC_Interrupt_Enable(void) 
{     
    #if (ADC_INDIVIDUAL_CHANNEL_INTERRUPT_FEATURE_AVAILABLE)
        ADC1_IndividualChannelInterruptEnable(MCAF_ADC_POTENTIOMETER);
    #else
        ADC1_InterruptEnable(); 
    #endif
}

/**
 * Returns whether or not an ADC input has been 
 * sampled in the current ISR.
 * @param channel ADC input caller is checking
 * @param selection ADC input that has been sampled this ISR
*/
inline static bool HAL_ADC_IsSampled(ADC1_CHANNEL channel, const HAL_ADC_SELECT_T selection)
{
    #if !(ADC1_SCAN_MODE_SELECTED)
        switch(selection)
        {
            case HADC_POTENTIOMETER:
            {
                return channel == MCAF_ADC_POTENTIOMETER;
            }
            case HADC_VDC:
            default:
            {
                return channel == MCAF_ADC_DCLINK_VOLTAGE;
            }
        }
    #else
        return true;
    #endif
}

/**
 * Schedules the next ADC analog input to be sampled.
 * @param pselect pointer to ADC selection structure
*/
inline static void HAL_ADC_ScheduleNextSample(HAL_ADC_SELECT_T * const pselect)
{
    #if !(ADC1_SCAN_MODE_SELECTED)
        if (*pselect == HADC_POTENTIOMETER)
        {
            *pselect = HADC_VDC;
            ADC1_ChannelSelect(MCAF_ADC_DCLINK_VOLTAGE);
        }
        else
        {
            *pselect = HADC_POTENTIOMETER;
            ADC1_ChannelSelect(MCAF_ADC_POTENTIOMETER);
        }
    #endif
}

/**
 * Converts a signed input to an unsigned value
 * @param input input to be converted to unsigned value
 * @return unsigned value
*/
inline static int16_t HAL_ADC_UnsignedFromSignedInput(int16_t input) { return input + 0x8000; }

/**
  Sub-section: Interrupt Module Access Functions
*/

/**
* Returns the interrupt vector number.
* @example
* <code>
* vecNum = HAL_InterruptVector_Get();
* </code>
*/
inline static uint16_t HAL_InterruptVector_Get(void) { return _VECNUM; }

/**
  Sub-section: DMA Module Access Functions
*/

/**
 * Handles the DMA Error trap and returns whether or not it was properly handled
 * @return true = DMA Error was handled, false = DMA Error was not handled
 */
bool HAL_DMA_ErrorHandler(void);

/**
  Sub-section: UART Module Access Functions
*/

/**
* Initializes the UART module
*/
inline static void HAL_UART_Initialize(void) { UART1_Initialize(); }

/**
 * Writes data to the UART tx buffer
 * @param data data to be written to the buffer
 */
inline static void HAL_UART_Write(uint8_t data) { UART1_Write(data); }

/**
 * Reads data from the UART rx buffer
 * @return data received from the UART rx buffer
 */
inline static uint8_t HAL_UART_Read(void) { return UART1_Read(); }

/**
 * States whether or not the UART rx buffer contains data
 * @return true = UART rx buffer has data false = UART rx buffer does not have data
 */
inline static bool HAL_UART_IsRxReady(void) { return UART1_IsRxReady(); }

/**
 * States whether or not the UART tx buffer is ready for more data
 * @return true = UART tx buffer can accept more data false = UART tx buffer can not accept more data
 */
inline static bool HAL_UART_IsTxReady(void) { return UART1_IsTxReady(); }


/**
  Sub-section: Watchdog Module Access Functions
*/

/**
* Clears the Watchdog timer
*/
inline static void HAL_WATCHDOG_Timer_Clear(void) { WATCHDOG_TimerClear(); }

/**
* Enables the Watchdog timer
*/
inline static void HAL_WATCHDOG_Timer_Enable(void) { WATCHDOG_TimerSoftwareEnable(); }

/**
  Sub-section: CORCON Module Access Functions
*/

/**
 * Gets the CORCON register value
 * @return CORCON register value
 */
inline static uint16_t HAL_CORCON_RegisterValue_Get(void) { return SYSTEM_CORCONRegisterValueGet(); }

/**
 * Sets the value of the CORCON register
 * @param reg_value register value to be set for the CORCON register
 */
inline static void HAL_CORCON_RegisterValue_Set(uint16_t reg_value) { SYSTEM_CORCONRegisterValueSet(reg_value); }

/**
* Initializes the CORCON module
*/
inline static void HAL_CORCON_Initialize(void) { SYSTEM_CORCONModeOperatingSet(CORCON_MODE_ENABLEALLSATNORMAL_ROUNDBIASED); }

/**
  Sub-section: TMR Module Access Functions
*/

/**
* Starts the profiling timer used to time the various operations
*/
inline static void HAL_ProfilingCounter_Start(void) { TMR1_Start(); }

/**
 * Gets the timer value of the profiling timer
 * @return profiling timer counter value
 */
inline static uint16_t HAL_ProfilingCounter_Get(void) { return TMR1_Counter16BitGet(); }

/**
* Starts the board timer used to time the initialization of the board
*/
inline static void HAL_BoardTimer_Start(void) { TMR2_Start(); }

/**
* Stops the board timer used to time the initialization of the board
*/
inline static void HAL_BoardTimer_Stop(void) { TMR2_Stop(); }

/**
 * Returns whether or not the board timing is finished
 * @return true = board timing is finished, false =  board timing is still in progress
 */
inline static bool HAL_BoardTimer_NotReady(void) { return !TMR2_GetElapsedThenClear(); }

#ifdef __cplusplus
}
#endif

#endif /* __HAF_H */
