/**
 * pll.h
 * 
 * Hosts components of the PLL estimator
 * 
 * Component: commutation
 */

/* *********************************************************************
 *
 * Motor Control Application Framework
 * R5/RC11 (commit 98456, build on 2020 Feb 07)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#ifndef __PLL_H
#define __PLL_H

#include <stdint.h>
#include "motor_control_types.h"
#include "units.h"
#include "commutation/common.h"
#include "parameters/pll_params.h"

#ifdef __cplusplus
extern "C" {
#endif
    
/**
 * State variables for PLL estimator
 */
typedef struct tagMCAF_ESTIMATOR_PLL
{
	/*
     * Runtime-adjustable parameters
	 *
	 * These values are typically set once, at startup,
	 * but may be adjusted using real-time diagnostic tools.
     */
	
    int16_t dtAngular;          /** Integration scaling factor dt from electrical frequency to electrical angle */
    int16_t rhoOffset;          /** Offset angle used to compensate the estimated rotor angle */
    int16_t rs;                 /** Value of stator resistance */
    int16_t ls;                 /** Value of stator inductance */
    int16_t lsBase;             /** Value of stator inductance for base speed (nominal) */
    int16_t invKFi;             /** Inverse value of BEMF constant */
    int16_t invKFiBase;         /** Inverse value of BEMF constant at base speed (nominal) value */
    int16_t dIlimitLS;          /** Delta current limit used for low velocity range */
    int16_t dIlimitHS;          /** Delta current limit used for high velocity range */
    int16_t kEsdqFilter;        /** Filter constant used for filtering BEMF voltage */
    int16_t kVelEstimFilter;    /** Filter constant used for filtering estimated velocity */

	/*
     * State variables
     *
	 * The state of the estimator at any given instant 
	 * is completely determined by its state variables.
	 *
	 * At each new step of the estimator, the state variables can theoretically
	 * be expressed as a deterministic function of the following values:
	 *
	 *   - state variables at the previous step
	 *   - runtime-adjustable parameters
	 *   - inputs to the estimator step function
	 */
    int32_t rhoStateVar;        /** Internal state variable for rotor angle */
    int16_t rho;                /** Estimated rotor angle prior to offset compensation */
    int16_t diCounter;          /** Counter index used to track current sample history */
    MCAF_U_VOLTAGE_DQ esdqFiltered;       /** Filtered value of BEMF in d-q reference frame */
    struct
    {
        int32_t d;
        int32_t q;
    } esdqStateVar;             /** State variable for BEMF in d-q reference frame */
    MCAF_U_VELOCITY_ELEC omegaElectrical;    /** Estimated velocity - scaled and filtered */
    int32_t velEstimStateVar;   /** State Variable for estimated velocity */
    MCAF_U_VOLTAGE_ALPHABETA lastValphabeta;     /** Value of Valphabeta from previous control step */
    MCAF_U_CURRENT_ALPHABETA lastIalphabeta[PLL_LOWSPEED_DIBYDT_PRESCALER];  /** Array storing a history of
                                                                     * previous Ialphabeta values */
	
	/*
	 * Auxiliary variables
	 *
	 * These values can be derived from the state variables
     * using memory-less calculations. 
	 *
	 * They are usually output or intermediate variables,
	 * and are typically retained in RAM to support data logging 
	 * with real-time diagnostic tools.
	 */
    int16_t omegaMr;            /** Estimated velocity that is unscaled and unfiltered */
    MCAF_U_VOLTAGE_ALPHABETA esalphabeta; /** Calculated BEMF in alpha-beta reference frame */
    MCAF_U_VOLTAGE_DQ esdq;               /** Calculated BEMF in d-q reference frame */
    MCAF_U_DIMENSIONLESS_SINCOS sincos;   /** Sine and cosine component of calculated rotor angle */
    MCAF_U_ANGLE_ELEC thetaElectrical;    /** Calculated rotor angle - offset compensated */
    MCAF_U_VOLTAGE_ALPHABETA vInductance; /** Calculated value of voltage across stator inductance */
    MCAF_U_VOLTAGE irDropAlpha;           /** Calculated value of voltage across stator resistance */
    MCAF_U_VOLTAGE irDropBeta;            /** Calculated value of voltage across stator resistance */
} MCAF_ESTIMATOR_PLL_T;

/**
 * Initializes PLL state variables on reset.
 * Summary: Initializes PLL state variables.
 * @param pll PLL state variable structure
 */
void MCAF_EstimatorPllInit(MCAF_ESTIMATOR_PLL_T *pll);

/**
 * Initializes PLL state variables prior to starting motor.
 * 
 * @param pll PLL state variable structure
 */
void MCAF_EstimatorPllStartupInit(MCAF_ESTIMATOR_PLL_T *pll);

/**
 * Executes one control step of the PLL estimator.
 * Summary: Executes one control step of the PLL estimator.
 * @param pll PLL state variable structure
 * @param pinput Common estimator inputs (e.g. stationary-frame voltage and current)
 */
void MCAF_EstimatorPllStep(MCAF_ESTIMATOR_PLL_T *pll, const MCAF_ESTIMATOR_INPUTS_T *pinput);

/**
 * Returns commutation angle
 * 
 * @param pll state
 * @return commutation angle
 */
inline static MCAF_U_ANGLE_ELEC MCAF_EstimatorPllCommutationAngle(const MCAF_ESTIMATOR_PLL_T *pll)
{
    return pll->thetaElectrical;
}

/**
 * Returns electrical frequency
 * 
 * @param pll state
 * @return electrical frequency
 */
inline static MCAF_U_VELOCITY_ELEC MCAF_EstimatorPllElectricalFrequency(const MCAF_ESTIMATOR_PLL_T *pll)
{
    return pll->omegaElectrical;
}

#ifdef __cplusplus
}
#endif

#endif /* __PLL_H */