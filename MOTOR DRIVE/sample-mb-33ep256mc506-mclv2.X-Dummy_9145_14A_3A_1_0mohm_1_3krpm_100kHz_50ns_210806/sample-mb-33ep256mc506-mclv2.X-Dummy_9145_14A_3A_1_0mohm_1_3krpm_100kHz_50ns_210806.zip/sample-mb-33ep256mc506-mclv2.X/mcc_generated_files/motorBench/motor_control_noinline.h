#include "motor_control_mapping.h"
#include "motor_control_declarations.h"

/* 
 * This file is used to pull in portions of motor_control.h
 * without including the inline functions, which are not used at present.
 */
