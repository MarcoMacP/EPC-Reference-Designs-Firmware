/**
 * mcaf_sample_application.c
 *
 * Main program entry point
 * 
 * Component: main application
 */

/* *********************************************************************
 * (c) 2017 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(TM) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
* *****************************************************************************/

#include <stdbool.h>
#include "board_service.h"
#include "hal.h"
#include "system_state.h"
#include "state_machine.h"
#include "system_init.h"
#include "foc.h"
#include "diagnostics.h"
#include "monitor.h"
#include "stall_detect.h"
#include "recover.h"
#include "mcaf_watchdog.h"
#include "mcaf_traps.h"
#include "ui.h"
#include "parameters/init_params.h"
#include "mcaf_main.h"
#include "test_harness.h"
#include "fault_detect.h"
#include "mcapi.h"

typedef struct tagAPPLICATION_DATA
{
    int16_t motorDirection;
    int16_t motorVelocityCommand;
    int16_t motorVelocityCommandMinimum;
    int16_t motorVelocityCommandMaximum;
    bool hardwareUiEnabled;
} APPLICATION_DATA;

/** Global instance of the main set of motor state variables */
MCAF_MOTOR_DATA motor;
/** Global instance of the main set of system state variables */
MCAF_SYSTEM_DATA systemData;

APPLICATION_DATA app;

extern volatile MCAF_WATCHDOG_T watchdog;

#define Timer_Callback TMR2_CallBack
#define Timer_Start    TMR2_Start

/**
 * Determines the appropriate velocity command for a given input of unipolar
 * speed reference.
 * @param app application state data
 * @param rawUnipolarValue unipolar speed reference input
 * @return velocity command
 */
inline static int16_t APP_DetermineVelocityCommand(APPLICATION_DATA *app, uint16_t rawUnipolarValue)
{
    int16_t velocityRange = app->motorVelocityCommandMaximum - app->motorVelocityCommandMinimum;
    int16_t unsignedSpeed = 
	          (UTIL_mulus(rawUnipolarValue, velocityRange) >> 16)
              + app->motorVelocityCommandMinimum;
    return unsignedSpeed*app->motorDirection;
}

/**
 * Initializes the application state variables.
 * @param app application state data
 * @param api MCAPI state data
 */
void APP_ApplicationInitialize(APPLICATION_DATA *app, volatile MCAPI_MOTOR_DATA *api)
{
    app->motorDirection = 1;
    app->motorVelocityCommand = MCAPI_VelocityReferenceMinimumGet(api);
    app->hardwareUiEnabled = true;
    app->motorVelocityCommandMinimum = MCAPI_VelocityReferenceMinimumGet(api);
    app->motorVelocityCommandMaximum = MCAPI_VelocityReferenceMaximumGet(api);
}

/**
 * Executes one step of the application.
 * @param app application data
 * @param api MCAPI state data
 */
void APP_ApplicationStep(APPLICATION_DATA *app, volatile MCAPI_MOTOR_DATA *api)
{
    if (app->hardwareUiEnabled)
    {
        /* Use potentiometer to set motor velocity command */
        int16_t potentiometerValue = MCAF_BoardServicePotentiometerValue();
        app->motorVelocityCommand = APP_DetermineVelocityCommand(app, potentiometerValue);
        MCAPI_VelocityReferenceSet(api, app->motorVelocityCommand);
        
        /* Button2 toggles motor direction */
        if (MCAF_ButtonGp2_EventGet())
        {
            MCAF_ButtonGp2_EventClear();
            app->motorDirection = app->motorDirection * -1;
        }
        
        /* Button1 toggles motor state + clears motor fault
         * by reading MCAF state and implementing a simple UI logic:
         * if motor is stopped, start it
         * if motor is starting or running or stopping, stop it
         * if motor is in a fault, clear it
         * if motor is in a test state, do nothing
         *  */
        if (MCAF_ButtonGp1_EventGet())
        {
            MCAF_ButtonGp1_EventClear();
            
            MCAPI_MOTOR_STATE motorState = MCAPI_OperatingStatusGet(api);
            switch (motorState)
            {
                case MCAPI_MOTOR_STOPPED:
                {
                    MCAPI_MotorStart(api);
                    break;
                }

                case MCAPI_MOTOR_STARTING:
                case MCAPI_MOTOR_RUNNING:
                case MCAPI_MOTOR_STOPPING:
                {
                    MCAPI_MotorStop(api);
                    break;
                }

                case MCAPI_MOTOR_FAULT:
                {
                    uint16_t faultFlags = MCAPI_FaultStatusGet(api);
                    MCAPI_FaultStatusClear(api, faultFlags);
                    break;
                }

                case MCAPI_MOTOR_DIAGSTATE:
                {
                    /* do nothing */
                    break;
                }
            }
        }        
    }
}

/**
 * This is an application owned timer the user is responsible for configuring. 
 * The application timer period needs to match the value set in motorBench Customize page.
 */
void Timer_Callback(void)
{
    MCAF_BoardServiceTasks();
    APP_ApplicationStep(&app, &motor.apiData);
}

bool MCAF_MainInit(void)
{
    MCAF_SystemInit(&systemData);
    MCAF_BoardServiceInit();
    MCAF_UiInit(&motor.ui);
    MCAF_MonitorInit(&motor.monitor);
    MCAF_StallDetectInit(&motor.stallDetect);
    MCAF_FaultDetectInit(&motor.faultDetect);
    MCAF_RecoveryInit(&motor.recovery);
    MCAF_SystemStateMachine_Init(&motor);
    MCAF_SystemTestHarness_Init(&systemData.testing);
    MCAPI_Initialize(&motor.apiData);
    APP_ApplicationInitialize(&app, &motor.apiData);
    
    /* Check reset cause and act upon it, prior to clearing the watchdog,
     * (see notes in declaration of MCAF_CheckResetCause)
     */
    MCAF_CheckResetCause();
    HAL_WATCHDOG_Timer_Enable();
    MCAF_WatchdogManageMainLoop(&watchdog);
    
    MCAF_InitControlParameters_Motor1(&motor);
    
    bool success = MCAF_FocInit(&motor, &systemData);
    if (success)
    {
        MCAF_SystemStart(&systemData);
        Timer_Start();
    }
    return success;
}

void MCAF_MainLoop(void)
{
    /* State variables are fine to access w/o volatile qualifier for ISR
     * (since no interruptions)
     * but in main loop, the ISR may interrupt + we need to assume volatile.
     */
    volatile MCAF_MOTOR_DATA *pmotor = &motor;
    volatile MCAF_SYSTEM_DATA *psystemData = &systemData;
    volatile MCAF_WATCHDOG_T *pwatchdog = &watchdog;
    
    MCAF_UiStepMain(&pmotor->ui);
    MCAF_SystemStateMachine_StepMain(pmotor);
    MCAF_WatchdogManageMainLoop(pwatchdog);
    MCAF_TestHarnessStepMain(&psystemData->testing);
    MCAF_DiagnosticsStepMain();
}
