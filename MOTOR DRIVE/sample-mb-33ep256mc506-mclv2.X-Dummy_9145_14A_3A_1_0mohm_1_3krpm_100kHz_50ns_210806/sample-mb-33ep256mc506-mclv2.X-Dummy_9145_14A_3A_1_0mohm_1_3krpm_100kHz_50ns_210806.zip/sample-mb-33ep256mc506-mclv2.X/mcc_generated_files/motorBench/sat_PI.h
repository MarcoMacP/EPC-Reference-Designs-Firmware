/**
 * sat_PI.h
 * 
 * Module to detect current and voltage saturation. It also contains modified PI controller   
 * 
 * Component: FOC
 */
 
/* *********************************************************************
 * 
 * Motor Control Application Framework
 * R6/RC8 (commit 102056, build on 2020 Aug 25)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#include <stdint.h>
#include "sat_PI_types.h"
#include "motor_control_types.h"

#ifndef SAT_PI_H
#define SAT_PI_H

#ifdef __cplusplus
extern "C" {
#endif



/**
 * Initializes parameters related to saturation detect
 * @param psat saturation detect state
 */
void MCAF_SatInit(MCAF_SAT_DETECT_T *psat);

/**
 * Updates status of saturation state flag
 * 
 * Summary : Saturation Detect
 * 
 * @param psat saturation detect state
 * @param pidq current vector Idq  
 * @param pvdq voltage vector Vdq
 * @param vDC DC link voltage
 *        (needed because voltage saturation limits are expressed 
 *         as a fraction of DC link voltage)
 */
void MCAF_SatDetect(MCAF_SAT_DETECT_T *psat, const MC_DQ_T *pidq, const MC_DQ_T *pvdq, int16_t vDC);

/**
 * Type-safe masking of saturation flags
 *
 * @param value input saturation status
 * @param mask allowable saturation status
 * @return masked saturation status
 */
inline static MCAF_SAT_STATE_T MCAF_SatMask(MCAF_SAT_STATE_T status, MCAF_SAT_STATE_T mask)
{
	return (MCAF_SAT_STATE_T)((uint16_t)status & (uint16_t)mask);
}

/**
 * 
 * Computes PI correction. 
 * If voltage or current saturation is detected and reference is greater than measure,
 * it will disable calculation of integral term (Anti-windup) 
 * 
 * Summary : Modified PI controller
 * 
 * @param in_Ref Reference Input
 * @param in_Meas Measured Input
 * @param state PI controller state 
 * @param sat_State status of saturation state to support anti-windup 
 * @param out output of PI controller
 * @param direction +1 for positive, -1 for negative 
 * @return returns value '1'
 */
void MCAF_ControllerPIUpdate(int16_t inReference, int16_t inMeasure, 
        MCAF_PISTATE_T *state, MCAF_SAT_STATE_T sat_State, int16_t *out,
        int16_t direction);

#ifdef __cplusplus
}
#endif

#endif /* SAT_PI_H */