/**
 * init_params.c
 * 
 * Initialization of motor parameters
 *
 * Component: FOC
 */ /*
 *
 * Motor Control Application Framework
 * R6/RC8 (commit 102056, build on 2020 Aug 25)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 *
 ******************************************************************************/

#include "../system_state.h"
#include "foc_params.h"

void MCAF_InitControlParameters_Motor1(MCAF_MOTOR_DATA *pmotor)
{
    /* ============= PI D Term =============== */
    pmotor->idCtrl.kp = DKP;
    pmotor->idCtrl.ki = DKI;
    pmotor->idCtrl.nkp = DKNP;
    pmotor->idCtrl.nki = DKNI;
    pmotor->idCtrl.kc = DKC;
    pmotor->idCtrl.outMax = MCAF_CURRENT_CTRL_D_OUT_LIMIT;
    pmotor->idCtrl.outMin = -MCAF_CURRENT_CTRL_D_OUT_LIMIT;
    pmotor->idqCtrlOutLimit.d = MCAF_CURRENT_CTRL_D_OUT_LIMIT;

    /* ============= PI Q Term =============== */
    pmotor->iqCtrl.kp = QKP;
    pmotor->iqCtrl.ki = QKI;
    pmotor->iqCtrl.nkp = QKNP;
    pmotor->iqCtrl.nki = QKNI;
    pmotor->iqCtrl.kc = QKC;
    pmotor->iqCtrl.outMax = MCAF_CURRENT_CTRL_Q_OUT_LIMIT;
    pmotor->iqCtrl.outMin = -MCAF_CURRENT_CTRL_Q_OUT_LIMIT;
    pmotor->idqCtrlOutLimit.q = MCAF_CURRENT_CTRL_Q_OUT_LIMIT;

    /* ============= PI W Term =============== */
    pmotor->omegaCtrl.kp = WKP;
    pmotor->omegaCtrl.ki = WKI;
    pmotor->omegaCtrl.nkp = WKNP;
    pmotor->omegaCtrl.nki = WKNI;
    pmotor->omegaCtrl.kc = WKC;
    pmotor->omegaCtrl.outMax = MCAF_VELOCITY_CTRL_IQ_OUT_LIMIT;
    pmotor->omegaCtrl.outMin = -MCAF_VELOCITY_CTRL_IQ_OUT_LIMIT;
	
    pmotor->iCmdLimit = MCAF_VELOCITY_CTRL_IQ_OUT_LIMIT;
}

