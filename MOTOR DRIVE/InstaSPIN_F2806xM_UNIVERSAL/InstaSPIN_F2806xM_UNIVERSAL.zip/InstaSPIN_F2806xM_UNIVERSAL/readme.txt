You must create your binary from a MotorWare project in CCS.
Once built, copy from the build location
ex: 
C:\ti\motorware\motorware_1_01_00_13\sw\solutions\instaspin_foc\boards\drv8301kit_revD\f28x\f2806xF\projects\ccs5\proj_lab02b\Flash


to the webapp location
ex: 
C:\ti\guicomposer\webapps\InstaSPIN_F2806xM_UNIVERSAL\

and rename
proj_lab###.out 

to
appProgram.out

then simply run
InstaSPIN_UNIVERSAL.exe
